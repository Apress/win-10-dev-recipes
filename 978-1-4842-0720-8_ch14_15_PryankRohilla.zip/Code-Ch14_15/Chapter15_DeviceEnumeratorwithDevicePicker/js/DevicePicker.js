﻿(function () {
    "use strict";

    var DevEnum = Windows.Devices.Enumeration;
    var devicePicker = null;
    
    var page = WinJS.UI.Pages.define("../default.html", {
        ready: function (element, options) {

           // Hook up button event handlers
            document.getElementById("showDevicePickerButton").addEventListener("click", showDevicePicker, false);
        }
    });

   
    function showDevicePicker() {
        var buttonRect;
        devicePicker = new DevEnum.DevicePicker();
        buttonRect = document.getElementById("showDevicePickerButton").getBoundingClientRect();
        var rect = { x: buttonRect.left, y: buttonRect.top, width: buttonRect.width, height: buttonRect.height };
    
            // Show the picker
            devicePicker.show(rect);
        
    }

})();