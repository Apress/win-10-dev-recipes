﻿(function () {
    "use strict";
    
    function GetControl() {
        WinJS.UI.processAll().done(function () {
            var adaptiveTilebutton = document.getElementById("btnUpdateAdaptiveTile");
            adaptiveTilebutton.addEventListener("click", AddAdaptiveTiles, false);

            var ScheduledAdaptiveTilebutton = document.getElementById("btnScheduledAdaptiveTile");
            ScheduledAdaptiveTilebutton.addEventListener("click", AddScheduledTileNotification, false);

            var toastNotificationbutton = document.getElementById("btnDisplayToast");
            toastNotificationbutton.addEventListener("click", AddToastNotification, false);

            var toastinteractiveNotificationbutton = document.getElementById("btnDisplayinteractiveToast");
            toastinteractiveNotificationbutton.addEventListener("click", AddInteractiveToastNotification, false);

            var badgeUpdatebutton = document.getElementById("btnUpdateBadge");
            badgeUpdatebutton.addEventListener("click", UpdateTileBadge, false);


        });
     
    }

    document.addEventListener("DOMContentLoaded", GetControl);

    function AddAdaptiveTiles() {
        var adaptivetileXml = "<tile><visual displayName=\"UWP recipes\" branding=\"name\">"
+ "<binding template=\"TileSmall\"><group><subgroup><text hint-style=\"subtitle\"> Windows 10 Apps recipes </text><text hint-style=\"subtitle\">Adaptive Tiles</text></subgroup></group></binding>"
+ "<binding template=\"TileMedium\"><group><subgroup><text hint-style=\"subtitle\"> Windows 10 Apps recipes </text><text hint-style=\"subtitle\">Adaptive Tiles</text></subgroup></group></binding>"
+ "<binding template=\"TileLarge\"><group><subgroup><text hint-style=\"subtitle\"> Windows 10 Apps recipes </text><text hint-style=\"subtitle\">Adaptive Tiles</text></subgroup></group></binding>"
+ "<binding template=\"TileWide\"><group><subgroup><text hint-style=\"subtitle\"> Windows 10 Apps recipes </text><text hint-style=\"subtitle\">Adaptive Tiles</text></subgroup></group></binding>"
+ "</visual></tile>";

        var adaptivetileDom = Windows.Data.Xml.Dom.XmlDocument();
        adaptivetileDom.loadXml(adaptivetileXml);
        var notifications = Windows.UI.Notifications;
        var tileNotification = new notifications.TileNotification(adaptivetileDom);
        notifications.TileUpdateManager.createTileUpdaterForApplication().update(tileNotification);


    }

    function AddToastNotification()
    {
        var toastXML = "<toast><visual>"
+ "<binding template=\"ToastGeneric\"><text>Apress Catalog</text><text>Apress is working on new Windows 10 Recipes guide</text>"
+ "<image placement=\"appLogoOverride\" src=\"/images/Alarm.png\" /><image placement=\"inline\" src=\"/images/Pattern-Blue-Dots-background.jpg\" /></binding>"
+ " </visual>"
+ " <audio src=\"ms-winsoundevent:Notification.Reminder\"/>"
+ "</toast>";
        var toastNotificationDom = Windows.Data.Xml.Dom.XmlDocument();
        toastNotificationDom.loadXml(toastXML);
        var notifications = Windows.UI.Notifications;

        // Get the toast notification manager for the current app.
        var notificationManager = notifications.ToastNotificationManager;
        // Create a toast notification from the XML, then create a ToastNotifier object
        // to send the toast.
        var toast = new notifications.ToastNotification(toastNotificationDom);
        notificationManager.createToastNotifier().show(toast);
    }


    function AddInteractiveToastNotification() {
        var toastXML = "<toast><visual>"
+ "<binding template=\"ToastGeneric\"><text>Apress Catalog</text><text>Apress is working on new Windows 10 Recipes guide</text>"
+ "<image placement=\"appLogoOverride\" src=\"/images/Alarm.png\" /><image placement=\"inline\" src=\"/images/Pattern-Blue-Dots-background.jpg\" /></binding>"
+ " </visual>"
+ "<actions><action content=\"check\" arguments=\"check\" imageUri=\"/images/storelogo.png\" /><action content=\"cancel\" arguments=\"cancel\" /></actions>"
+ " <audio src=\"ms-winsoundevent:Notification.Reminder\"/>"
+ "</toast>";
        var toastNotificationDom = Windows.Data.Xml.Dom.XmlDocument();
        toastNotificationDom.loadXml(toastXML);
        var notifications = Windows.UI.Notifications;

        // Get the toast notification manager for the current app.
        var notificationManager = notifications.ToastNotificationManager;
        // Create a toast notification from the XML, then create a ToastNotifier object
        // to send the toast.
        var toast = new notifications.ToastNotification(toastNotificationDom);
        notificationManager.createToastNotifier().show(toast);
    }
  
    function AddScheduledTileNotification() {

        var adaptivetileXml = "<tile><visual displayName=\"Future recipes\" branding=\"name\">"
+ "<binding template=\"TileSmall\"><group><subgroup><text hint-style=\"subtitle\"> Updated Tiles </text><text hint-style=\"subtitle\">Adaptive Tiles</text></subgroup></group></binding>"
+ "<binding template=\"TileMedium\"><group><subgroup><text hint-style=\"subtitle\">  Updated Tiles </text><text hint-style=\"subtitle\">Adaptive Tiles</text></subgroup></group></binding>"
+ "<binding template=\"TileLarge\"><group><subgroup><text hint-style=\"subtitle\">  Updated Tiles </text><text hint-style=\"subtitle\">Adaptive Tiles</text></subgroup></group></binding>"
+ "<binding template=\"TileWide\"><group><subgroup><text hint-style=\"subtitle\">  Updated Tiles </text><text hint-style=\"subtitle\">Adaptive Tiles</text></subgroup></group></binding>"
+ "</visual></tile>";
        var adaptivetileDom = Windows.Data.Xml.Dom.XmlDocument();
        adaptivetileDom.loadXml(adaptivetileXml);
        var currentTime = new Date();
        //notification should appear in 3 seconds
        var startTime = new Date(currentTime.getTime() + 3 * 1000);
        var scheduledTile = new Windows.UI.Notifications.ScheduledTileNotification(adaptivetileDom, startTime);
        //Give the scheduled tile notification an ID
        scheduledTile.id = "Future_Tile";
        var tileUpdater = Windows.UI.Notifications.TileUpdateManager.createTileUpdaterForApplication();
        tileUpdater.addToSchedule(scheduledTile);

    }

    function UpdateTileBadge()
    
    {
        AddAdaptiveTiles();
        var badgeXml = "<badge value=\"alarm\"/>";
        var badgeDom = Windows.Data.Xml.Dom.XmlDocument();
        badgeDom.loadXml(badgeXml);
        var notifications = Windows.UI.Notifications;
        var badgeNotification = new notifications.BadgeNotification(badgeDom);
        notifications.BadgeUpdateManager.createBadgeUpdaterForApplication().update(badgeNotification);
    }

})();
