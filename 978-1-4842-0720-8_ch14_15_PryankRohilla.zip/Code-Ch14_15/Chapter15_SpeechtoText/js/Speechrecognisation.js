﻿(function () {
    "use strict";
    
    function GetControl() {
        WinJS.UI.processAll().done(function () {
            var btnSpeak = document.getElementById("btnSpeak");
            btnSpeak.addEventListener("click", buttonSpeechRecognizerListConstraintClick, false);
            var resultTextArea = document.getElementById(resultTextArea);

        });
     
    }

    document.addEventListener("DOMContentLoaded", GetControl);

function buttonSpeechRecognizerListConstraintClick() {
    // Create an instance of SpeechRecognizer.
    var speechRecognizer =
      new Windows.Media.SpeechRecognition.SpeechRecognizer();

    // You could create this array dynamically.
    var responses = ["Yes", "No", "Hello", "Hello World"];

    // Add a web search grammar to the recognizer.
    var listConstraint =
        new Windows.Media.SpeechRecognition.SpeechRecognitionListConstraint(
        responses,
        "Responses");

    speechRecognizer.uiOptions.audiblePrompt = "Say what you want to test for...";
    speechRecognizer.uiOptions.exampleText = "Ex. 'Yes', 'No', 'Hello'";
    speechRecognizer.constraints.append(listConstraint);
    var resultTextArea = document.getElementById(resultTextArea);
    // Compile the default dictation grammar.
    speechRecognizer.compileConstraintsAsync().done(
      // Success function.
      function (result) {
          // Start recognition.
          speechRecognizer.recognizeWithUIAsync().done(
            // Success function.
            function (speechRecognitionResult) {
                // Do something with the recognition result.
                speechRecognizer.close();

            },
            // Error function.
            function (err) {
                if (typeof errorTextArea !== "undefined") {
                    errorTextArea.innerText = "Speech recognition failed.";
                }
                speechRecognizer.close();
            });
      },
      // Error function.
      function (err) {
          if (typeof errorTextArea !== "undefined") {
              errorTextArea.innerText = err;
          }
          speechRecognizer.close();
      });
   
}
})();
