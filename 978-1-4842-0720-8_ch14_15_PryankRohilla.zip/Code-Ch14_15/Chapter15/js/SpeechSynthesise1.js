﻿(function () {
    "use strict";
    
    function GetControl() {
        WinJS.UI.processAll().done(function () {
            try {
                synthesizer = new Windows.Media.SpeechSynthesis.SpeechSynthesizer();
                audio = new Audio();
                var btnSpeak = document.getElementById("btnSpeak");
                var voicesSelect = document.getElementById("voicesSelect");
                btnSpeak.addEventListener("click", speakFn, false);
                voicesSelect.addEventListener("click", setVoiceFunction, false);

                var rcns = Windows.ApplicationModel.Resources.Core;
                context = new rcns.ResourceContext();
                context.languages = new Array(synthesizer.voice.language);
                listbox_GetVoices();
                audio_SetUp();
            } catch (exception) {
                if (exception.number == -2147467263) {// E_NOTIMPL

                    // If media player components are not installed 
                    // this error may occur when instantiating the Audio object.
                    statusMessage.innerText = "Media Player components not found!";
                    btnSpeak.disabled = true;
                    textToSynthesize.disabled = true;
                }
            }

        });
     
    }

    document.addEventListener("DOMContentLoaded", GetControl);


    var synthesizer;
    var audio;

    // localization resources
    var context;
    var resourceMap;

    function audio_SetUp() {
        /// <summary>
        /// Sets up the voice  element's events so the app UI updates based on the current state of playback.
        /// </summary>
        audio.onplay = function () { // executes when the audio begins playing
            statusMessage.innerText = "Playing";
        };

        audio.onpause = function () { // executes when the user presses the stop button
            statusMessage.innerText = "Completed";
            btnSpeak.innerText = "Speak";
        };

        audio.onended = function () { // executes when the audio finishes playing
            statusMessage.innerText = "Completed";
            btnSpeak.innerText = "Speak";
            voicesSelect.disabled = false;
        };
    }
    function speakFn() {
        /// <summary>
        /// This is executed when the user clicks on the speak/stop button. It attempts to convert the 
        /// textbox content into a  voicestream, then plays the stream through the audio element.
        /// </summary>
        var btnSpeak = document.getElementById("btnSpeak");
        if (btnSpeak.innerText == "Stop") {
            voicesSelect.disabled = false;
            audio.pause();
            return;
        }

        // Changes the button label. You could also just disable the button if you don't want any user control.
        voicesSelect.disabled = true;
        btnSpeak.innerText = "Stop";
        statusBox.style.backgroundColor = "green";

        // Creates a stream from the text. This will be played using an audio element.
        synthesizer.synthesizeTextToStreamAsync(textToSynthesize.value).done(
            function (markersStream) {
                // Set the source and start playing the synthesized audio stream.
                var blob = MSApp.createBlobFromRandomAccessStream(markersStream.ContentType, markersStream);
                audio.src = URL.createObjectURL(blob, { oneTimeOnly: true });
                markersStream.seek(0);
                audio.play();
            },
            function (error) {
                errorMessage(error.message);
            });
    }
    function setVoiceFunction() {
        /// <summary>
        /// This is called when the user selects a voice from the drop down.
        /// </summary>
        if (voicesSelect.selectedIndex !== -1) {
            var allVoices = Windows.Media.SpeechSynthesis.SpeechSynthesizer.allVoices;

            // Use the selected index to find the voice.
            var selectedVoice = allVoices[voicesSelect.selectedIndex];

            synthesizer.voice = selectedVoice;

            // change the language of the sample text.
            context.languages = new Array(synthesizer.voice.language);
        }
    }

    function listbox_GetVoices() {
        /// <summary>
        /// This creates items out of the system installed voices. The voices are then displayed in a listbox.
        /// This allows the user to change the voice of the synthesizer in your app based on their preference.
        /// </summary>

        // Get the list of all of the voices installed on this machine.
        var allVoices = Windows.Media.SpeechSynthesis.SpeechSynthesizer.allVoices;

        // Get the currently selected voice.
        var defaultVoice = Windows.Media.SpeechSynthesis.SpeechSynthesizer.defaultVoice;
        var voicesSelect = document.getElementById("voicesSelect");
        for (var voiceIndex = 0; voiceIndex < allVoices.size; voiceIndex++) {
            var currVoice = allVoices[voiceIndex];
            var option = document.createElement("option");
            option.text = currVoice.displayName + " (" + currVoice.language + ")";
            voicesSelect.add(option, null);

            // Check to see if we're looking at the current voice and set it as selected in the listbox.
            if (currVoice.id === defaultVoice.id) {
                voicesSelect.selectedIndex = voiceIndex;
            }
        }
    }
    function errorMessage(text) {
        /// <summary>
        /// Sets the specified text area with the error message details.
        /// </summary>
        var errorTextArea = document.getElementById("errorTextArea");

        errorTextArea.innerText = text;
    }

})();

