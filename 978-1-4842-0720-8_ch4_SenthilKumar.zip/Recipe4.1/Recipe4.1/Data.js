﻿(function () {
    "use strict";
    function Initialize() {
        WinJS.UI.processAll().done(function () {
            var repeaterControl1 = document.getElementById('repeaterData').winControl;
            var Employees = new WinJS.Binding.List([
                { id: 1, name: "Senthil Kumar", designation: "Mobile Developer" },
                { id: 2, name: "Lohith GN", designation: "Web Developer" },
                { id: 3, name: "Vidyasagar", designation: "Game Developer" }
            ]);
            repeaterControl1.data = Employees;
            repeaterControl1.addEventListener("invoked",function(e)
            {
                var name = e.target.dataset.name;
                var message = new Windows.UI.Popups.MessageDialog(name);
                message.showAsync();
            })
        })
    }
    document.addEventListener("DOMContentLoaded", Initialize);
})();