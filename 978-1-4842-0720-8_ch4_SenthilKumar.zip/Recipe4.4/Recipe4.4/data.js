﻿(function () {
    "use strict";
    // List of Employees to be used a datasource.
    var lstEmployees = new WinJS.Binding.List([
        { id: 1, name: "Senthil Kumar" },
        { id: 2, name: "Lohith GN" },
        { id: 3, name: "Senthil Kumar B" },
        { id: 4, name: "Vidyasagar" },
    ]);
    function Initialize() {
        WinJS.UI.processAll().done(function () {
            // Get the Listview from the DOM
            var lstControl = document.getElementById('lstEmployees').winControl;
            // Get the Search Tex from the HTML Page
            var filterText = document.getElementById('txtSearch');
            lstControl.itemDataSource = lstEmployees.dataSource;
            filterText.addEventListener("keyup", function () {
                filterEmployee(lstControl, filterText.value);
            });
        });
    }
    // Function to filter the list
    function filterEmployee(listEmployee,searchtext)
    {
        var fileteredData = lstEmployees.createFiltered(function (item) {
            var result = item.name.toLowerCase().indexOf(searchtext);
            return item.name.toLowerCase().indexOf(searchtext) == 0;
        });
        listEmployee.itemDataSource = fileteredData.dataSource;
    }
    document.addEventListener("DOMContentLoaded", Initialize);
})();