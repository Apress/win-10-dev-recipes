﻿(function () {
    "use strict"; 
     var Employees = new WinJS.Binding.List([
         { id: 1, name: "Senthil Kumar", designation: "Mobile Developer" },
         { id: 2, name: "Lohith GN", designation: "Web Developer" },
         { id: 3, name: "Vidyasagar", designation: "Game Developer" }
         ]);
     WinJS.Namespace.define("recipeData",
         {
             Employees :Employees
         });   
})();
