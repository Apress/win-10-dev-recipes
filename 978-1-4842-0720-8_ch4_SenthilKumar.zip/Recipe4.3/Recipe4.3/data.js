﻿(function () {
    "use strict";
    function Initialize() {
        WinJS.UI.processAll().done(function () {
            var listControl1 = document.getElementById('listView1').winControl;
            var Employees = new WinJS.Binding.List([
                { id: 1, name: "Senthil Kumar", designation: "Mobile Developer" },
                { id: 2, name: "Lohith GN", designation: "Web Developer" },
                { id: 3, name: "Vidyasagar", designation: "Game Developer" },
                { id: 4, name: "Michael", designation: "Architect" }
            ]);
            listControl1.itemDataSource = Employees.dataSource;
            listControl1.addEventListener("iteminvoked", function (e) {
                var index = e.detail.itemIndex;
                e.detail.itemPromise.then(function (item) {
                    var message = new Windows.UI.Popups.MessageDialog(item.data.name);
                    message.showAsync();
                })
            })
        })
    }
    document.addEventListener("DOMContentLoaded", Initialize);
})();