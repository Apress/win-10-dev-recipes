﻿(function () {
    "use strict";
    function Initialize() {
        WinJS.UI.processAll().done(function () {
            var listView1 = document.getElementById("lvEmployees").winControl;

            var employeeList = new WinJS.Binding.List([
                { id: 1, name: "Senthil Kumar", technology: "Mobile" },
                { id: 2, name: "Michael", technology: "Web" },
                { id: 3, name: "Lohith", technology: "Web" },
                { id: 4, name: "Stephen", technology: "Mobile" },
                { id: 5, name: "Vidyasagar", technology: "Game" },
                { id: 6, name: "Joseph", technology: "Mobile" },
            ]);
            var groupedEmployees = employeeList.createGrouped(
                function (item) {
                    return item.technology;
                },
                function (item) {
                    return { technology: item.technology }
                },
                function (group1, group2) {
                    return group1 > group2 ? 1 : -1;
                });
            listView1.groupDataSource = groupedEmployees.groups.dataSource;
            listView1.itemDataSource = groupedEmployees.dataSource;
        });
    }
    document.addEventListener("DOMContentLoaded", Initialize);
})();