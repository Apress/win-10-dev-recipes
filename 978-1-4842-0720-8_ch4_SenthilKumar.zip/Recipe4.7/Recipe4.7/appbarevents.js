﻿(function () {
    "use strict";

    WinJS.UI.Pages.define("default.html", {
        ready: function (element, options) {
            element.querySelector("#cmdAdd").addEventListener("click", AddMethod, false);
            element.querySelector("#cmdRemove").addEventListener("click", RemoveMethod, false);
            element.querySelector("#cmdCamera").addEventListener("click", CameraMethod, false);
        }
    });

    // Command button functions
    function AddMethod() {
        
        var message = new Windows.UI.Popups.MessageDialog("Add Button Pressed");
        message.showAsync();
    }

    function RemoveMethod() {
        var message = new Windows.UI.Popups.MessageDialog("Remove button pressed");
        message.showAsync();
    }

    function CameraMethod() {
        var message = new Windows.UI.Popups.MessageDialog("Camera button pressed");
        message.showAsync();
    }
})();

