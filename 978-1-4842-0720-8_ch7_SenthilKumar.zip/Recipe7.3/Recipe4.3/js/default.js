﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
	"use strict";

	var app = WinJS.Application;
	var activation = Windows.ApplicationModel.Activation;
	app.onactivated = function (args) {
	    if (args.detail.kind === activation.ActivationKind.launch) {
	        if (args.detail.previousExecutionState === activation.ApplicationExecutionState.notRunning) {
	            // The app is newly launched
	            // Load the initial or default value for the app
	            console.log("Previous state is not running");
	        }
	        if (args.detail.previousExecutionState === activation.ApplicationExecutionState.closedByUser) {
	            console.log("Previous state is closed by the user");
	        }
			if (args.detail.previousExecutionState === activation.ApplicationExecutionState.terminated) {
			    console.log("Previous state is terminated");
			} 
			args.setPromise(WinJS.UI.processAll());
		}
	};

	app.start();
})();
