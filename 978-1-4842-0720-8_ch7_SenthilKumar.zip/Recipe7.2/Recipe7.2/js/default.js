﻿
(function () {
	"use strict";

	var app = WinJS.Application;
	var activation = Windows.ApplicationModel.Activation;
    WinJS.Application.addEventListener("error", function(eventArgs) {
        var errorMessage = new Windows.UI.Popups.MessageDialog("There was an error in the app. Kindly contact the app publisher");
        errorMessage.showAsync();
        return true;
    });

    app.onactivated = function (args) {
      
        args.setPromise(WinJS.UI.processAll());
        throw new WinJS.ErrorFromName();
    };
	app.start();
})();
