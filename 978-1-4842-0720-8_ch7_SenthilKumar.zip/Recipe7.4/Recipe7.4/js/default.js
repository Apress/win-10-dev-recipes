﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
	"use strict";

	var app = WinJS.Application;
	var activation = Windows.ApplicationModel.Activation;

	app.onactivated = function (args) {
		if (args.detail.kind === activation.ActivationKind.launch) {
		    if (args.detail.previousExecutionState === Windows.ApplicationModel.Activation.ApplicationExecutionState.notRunning) {
		        console.log("setting the initial values");
		        document.getElementById("txt1").value = '';
		        document.getElementById("txt2").value = '';
		    }
		    if (args.detail.previousExecutionState === Windows.ApplicationModel.Activation.ApplicationExecutionState.closedByUser) {
		        console.log("setting the initial values");
		        document.getElementById("txt1").value = '';
		        document.getElementById("txt2").value = '';
		    }
		    if (args.detail.previousExecutionState === Windows.ApplicationModel.Activation.ApplicationExecutionState.terminated) {
		        console.log("setting the previous state values");
		        document.getElementById("txt1").value = WinJS.Application.sessionState.txt1;
		        document.getElementById("txt2").value = WinJS.Application.sessionState.txt2;
		    }
			args.setPromise(WinJS.UI.processAll());
		}
	};
	app.oncheckpoint = function (args) {
	    WinJS.Application.sessionState.txt1 = document.getElementById("txt1").value;
	    WinJS.Application.sessionState.txt2 = document.getElementById("txt2").value;
	};

	app.start();
})();
