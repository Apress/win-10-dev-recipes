﻿(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            var page2link = document.getElementById('lnkPage2');
            page2link.addEventListener('click', function(eventargs) {
                eventargs.preventDefault();
                WinJS.Navigation.navigate("/pages/page1.html");
            });
        }
    });
})();
