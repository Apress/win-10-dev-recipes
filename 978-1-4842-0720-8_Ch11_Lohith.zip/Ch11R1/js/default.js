﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
	"use strict";

	var app = WinJS.Application;
	var activation = Windows.ApplicationModel.Activation;

	app.onactivated = function (args) {
		if (args.detail.kind === activation.ActivationKind.launch) {
			if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
				
			    var task = null,
                    taskRegistered = false,
                    background = Windows.ApplicationModel.Background,
                    iter = background.BackgroundTaskRegistration.allTasks.first();

                while (iter.hasCurrent) {
                    task = iter.current.value;
                    if (task.name === exampleTaskName) {
                        taskRegistered = true;
                        break;
                    }
                    iter.moveNext();
                }

                if (taskRegistered != true) {
                    var builder = new Windows.ApplicationModel.Background.BackgroundTaskBuilder();
                    var trigger = new Windows.ApplicationModel.Background.SystemTrigger(Windows.ApplicationModel.Background.SystemTriggerType.timeZoneChange, false);
                    builder.name = exampleTaskName;
                    builder.taskEntryPoint = "js\\mytask.js";
                    builder.setTrigger(trigger);
                    task = builder.register();
                }
                task.addEventListener("completed", function (args) {
                    var settings = Windows.Storage.ApplicationData.current.localSettings;
                    var key = args.target.name;
                    settings.values[key] = "Completed";
                })

			} else {
				// TODO: This application was suspended and then terminated.
				// To create a smooth user experience, restore application state here so that it looks like the app never stopped running.
			}
			args.setPromise(WinJS.UI.processAll());
		}
	};

	app.oncheckpoint = function (args) {
		// TODO: This application is about to be suspended. Save any state that needs to persist across suspensions here.
		// You might use the WinJS.Application.sessionState object, which is automatically saved and restored across suspension.
		// If you need to complete an asynchronous operation before your application is suspended, call args.setPromise().
	};

	app.start();
})();
