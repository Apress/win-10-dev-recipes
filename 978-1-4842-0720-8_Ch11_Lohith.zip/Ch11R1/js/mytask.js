﻿(function () {

    "use strict";
    
    //gets the current instance of the background task
    var backgroundTaskInstance = Windows.UI.WebUI.WebUIBackgroundTaskInstance.current;

    var canceled = false,
        settings = Windows.Storage.ApplicationData.current.localSettings,
        key = backgroundTaskInstance.task.name;

    backgroundTaskInstance.addEventListener("canceled", OnCanceled);

    //checking if the background task is cancelled by the user.
    if (!canceled) {
        doWork();
    }
    else {
        settings.values[key] = "Canceled";
        close();
    }

    //the function which performs the main work as part of our backgrund task
    function doWork() {
        settings.values[key] = "Starting"

        //Your code to do work in the background
        //...

        settings.values[key] = "Succeeded";
        settings.values[key] = "Closing";

        //call close when task is done
        close();
    }

    function OnCanceled(sender, reason) {
        canceled = true;
    }

})();