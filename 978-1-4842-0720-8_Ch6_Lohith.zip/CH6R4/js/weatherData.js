﻿(function (undefined) {
    'use strict';


    var weatherData = [
        {
            date: formatDateString(new Date().getDate()),
            imgSrc: "images/tile-snow.png",
            hi: "32&deg;",
            low: "16&deg;",
            temp: "24&deg;",
            feelsLike: "28&deg;",
            chanceOfSnow: "88%",
            humidity: "64%",
            wind: "18 MPH NW",
            map: "images/placeholder-sdk.png",
            info: "html/rainier.html"
        },
        {
            date: formatDateString(new Date().getDate() + 1),
            imgSrc: "images/tile-snow.png",
            hi: "32&deg;",
            low: "16&deg;",
            temp: "24&deg;",
            feelsLike: "28&deg;",
            chanceOfSnow: "88%",
            humidity: "64%",
            wind: "18 MPH NW",
            map: "images/placeholder-sdk.png"
        },
        {
            date: formatDateString(new Date().getDate() + 2),
            imgSrc: "images/tile-snow.png",
            hi: "32&deg;",
            low: "16&deg;",
            temp: "24&deg;",
            feelsLike: "28&deg;",
            chanceOfSnow: "88%",
            humidity: "64%",
            wind: "18 MPH NW",
            map: "images/placeholder-sdk.png"
        },
        {
            date: formatDateString(new Date().getDate() + 3),
            imgSrc: "images/tile-snow.png",
            hi: "32&deg;",
            low: "16&deg;",
            temp: "24&deg;",
            feelsLike: "28&deg;",
            chanceOfSnow: "88%",
            humidity: "64%",
            wind: "18 MPH NW",
            map: "images/placeholder-sdk.png"
        },
        {
            date: formatDateString(new Date().getDate() + 4),
            imgSrc: "images/tile-snow.png",
            hi: "32&deg;",
            low: "16&deg;",
            temp: "24&deg;",
            feelsLike: "28&deg;",
            chanceOfSnow: "88%",
            humidity: "64%",
            wind: "18 MPH NW",
            map: "images/placeholder-sdk.png"
        },
        {
            date: formatDateString(new Date().getDate() + 5),
            imgSrc: "images/tile-snow.png",
            hi: "32&deg;",
            low: "16&deg;",
            temp: "24&deg;",
            feelsLike: "28&deg;",
            chanceOfSnow: "88%",
            humidity: "64%",
            wind: "18 MPH NW",
            map: "images/placeholder-sdk.png"
        },
        {
            date: formatDateString(new Date().getDate() + 6),
            imgSrc: "images/tile-snow.png",
            hi: "32&deg;",
            low: "16&deg;",
            temp: "24&deg;",
            feelsLike: "28&deg;",
            chanceOfSnow: "88%",
            humidity: "64%",
            wind: "18 MPH NW",
            map: "images/placeholder-sdk.png"
        },
        {
            date: formatDateString(new Date().getDate() + 7),
            imgSrc: "images/tile-snow.png",
            hi: "32&deg;",
            low: "16&deg;",
            temp: "24&deg;",
            feelsLike: "28&deg;",
            chanceOfSnow: "88%",
            humidity: "64%",
            wind: "18 MPH NW",
            map: "images/placeholder-sdk.png"
        },
        {
            date: formatDateString(new Date().getDate() + 8),
            imgSrc: "images/tile-snow.png",
            hi: "32&deg;",
            low: "16&deg;",
            temp: "24&deg;",
            feelsLike: "28&deg;",
            chanceOfSnow: "88%",
            humidity: "64%",
            wind: "18 MPH NW",
            map: "images/placeholder-sdk.png"
        },
        {
            date: formatDateString(new Date().getDate() + 9),
            imgSrc: "images/tile-snow.png",
            hi: "32&deg;",
            low: "16&deg;",
            temp: "24&deg;",
            feelsLike: "28&deg;",
            chanceOfSnow: "88%",
            humidity: "64%",
            wind: "18 MPH NW",
            map: "images/placeholder-sdk.png"
        },
    ];

    function formatDateString(date) {
        var daysOfWeek = ["Sun", "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat"];
        var nearDays = ["Yesterday", "Today", "Tomorrow"];
        var dayDelta = date - new Date().getDate() + 1;
        var dateString = "";
        if (dayDelta < 3) {
            dateString = nearDays[dayDelta];
        }
        else {
            dateString = daysOfWeek[date % 7] +
            " <span class='day'>" + date + "</span>";
        }
        return dateString;
    };


    var weatherDataList = new WinJS.Binding.List(weatherData);

    WinJS.Namespace.define("FluidApp.Data", {
        weatherData : weatherDataList            
    })

})();
