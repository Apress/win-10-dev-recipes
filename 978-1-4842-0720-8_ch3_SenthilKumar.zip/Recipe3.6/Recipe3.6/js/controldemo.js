﻿(function () {
    "use strict";
    function GetControl() {
        WinJS.UI.processAll().done(function () {
            var datepick = document.getElementById("Birthday").winControl;
            var infoelement = document.getElementById("info");
            datepick.addEventListener('change', function (args) {
                infoelement.innerHTML = "The selected date is " +
                    datepick.current.toDateString();

            })
        });
    }
    document.addEventListener("DOMContentLoaded", GetControl);

})();
