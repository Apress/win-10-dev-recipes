﻿(function () {
    "use strict";
    function GetControl() {
        WinJS.UI.processAll().done(function () {
            var toggleButton = document.getElementById("locationServices").winControl;
            var InfoElement = document.getElementById("info");
            toggleButton.addEventListener('change', function (args) {
                if (toggleButton.checked) {
                    InfoElement.innerHTML = "Location Services enabled";
                }
                else {
                    InfoElement.innerHTML = "Location Services disabled";
                }
            })
        });
    }

    document.addEventListener("DOMContentLoaded", GetControl);

})();
