﻿(function () {
    "use strict";
    function AddControl() {
        var ratingDiv = document.getElementById("rating");
        var ratingCtrl = new WinJS.UI.Rating(ratingDiv);
    }
    document.addEventListener("DOMContentLoaded", AddControl);
})();
