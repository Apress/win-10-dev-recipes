﻿(function () {
    "use strict";
    function GetControl() {
        WinJS.UI.processAll().done(function () {
            var datepick = document.getElementById("timeSelector").winControl;
            var InfoEelement = document.getElementById("info");
            datepick.addEventListener('change', function (args) {
                InfoEelement.innerHTML = "The selected time is " +
                    datepick.current.toTimeString();

            })
        });
    }
    document.addEventListener("DOMContentLoaded", GetControl);

})();
