﻿(function () {
    "use strict";
    function GetControl() {
        WinJS.UI.processAll().done(function () {
            var ratingControl = document.getElementById("rating").winControl;
            ratingControl.userRating = 2;
        });
    }

    document.addEventListener("DOMContentLoaded", GetControl);

})();
