﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=392286
(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
            } else {
            }
            args.setPromise(WinJS.UI.processAll());

            var client = new WindowsAzure.MobileServiceClient(
				"https://winjsrecipes.azure-mobile.net/",
				"LQvwFdSmfYBGNQFsoXyxjpwxxRPqfU52"
			);

            var todoTable = client.getTable('todo');

            var todoItems = new WinJS.Binding.List();

            var insertTodoItem = function (todoItem) {

                todoTable.insert(todoItem).done(function (item) {
                    todoItems.push(item);
                });
            };

            var refreshTodoItems = function () {
              
                todoTable.where({ complete: false }).orderByDescending("text")
                    .read()
                    .done(function (results) {
                        todoItems = new WinJS.Binding.List(results);
                        listItems.winControl.itemDataSource = todoItems.dataSource;
                    });
            };

            var updateCheckedTodoItem = function (todoItem) {

                todoTable.update(todoItem).done(function (item) {
                    todoItems.splice(todoItems.indexOf(item), 1);
                });
            };

            buttonSave.addEventListener("click", function () {
                insertTodoItem({
                    text: textInput.value,
                    complete: false
                });
            });

            buttonRefresh.addEventListener("click", function () {
                refreshTodoItems();
            });

            listItems.addEventListener("change", function (eventArgs) {
                var todoItem = eventArgs.target.dataContext.backingData;
                todoItem.complete = eventArgs.target.checked;
                updateCheckedTodoItem(todoItem);

            });

            refreshTodoItems();


        }
    };

    app.oncheckpoint = function (args) {

    };

    app.start();
})();