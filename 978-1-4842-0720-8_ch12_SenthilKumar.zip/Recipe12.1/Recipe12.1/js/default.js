﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=392286
(function () {
    "use strict";
    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                // TODO: This application has been newly launched. Initialize
                // your application here.
            } else {
                // TODO: This application has been reactivated from suspension.
                // Restore application state here.
            }
            args.setPromise(WinJS.UI.processAll().
               done(function () {
                   // Add an event handler to the button.
                   document.querySelector("#btnLocation").addEventListener("click",
                       getLocation);
               }));

        }
    };
    var geolocation = null;

    function getLocation() {
        if (geolocation == null) {
            geolocation = new Windows.Devices.Geolocation.Geolocator();
        }
        if (geolocation != null) {
            geolocation.getGeopositionAsync().then(getPosition);
        }
    }
    function getPosition(position) {
        document.getElementById('latitude').innerHTML = position.coordinate.point.position.latitude;
        document.getElementById('longitude').innerHTML = position.coordinate.point.position.longitude;
        document.getElementById('accuracy').innerHTML = position.coordinate.accuracy;
    }

    app.oncheckpoint = function (args) {

    };

    app.start();
})();
