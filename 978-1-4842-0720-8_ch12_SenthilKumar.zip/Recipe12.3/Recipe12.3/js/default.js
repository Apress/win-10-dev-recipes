﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=392286
(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                // TODO: This application has been newly launched. Initialize
                // your application here.
            } else {
                // TODO: This application has been reactivated from suspension.
                // Restore application state here.
            }
            args.setPromise(WinJS.UI.processAll().
                 done(function () {

                     // Add an event handler to the button.
                     document.querySelector("#btnLocation").addEventListener("click",
                         GetLocation);

                 }));

        }
    };

    var nav = null;

    function GetLocation() {
        if (nav == null) {
            nav = window.navigator;
        }

        var geoloc = nav.geolocation;
        if (geoloc != null) {
            geoloc.getCurrentPosition(Onsuccess, Onerror);
        }
    }

    // after getting the location information
    function Onsuccess(position) {
        document.getElementById("latitude").innerHTML =
            position.coords.latitude;
        document.getElementById("longitude").innerHTML =
            position.coords.longitude;

    }
    // On error when trying to get the location
    function Onerror(error) {
        var errorMessage = "";
        switch (error.code) {
            case error.PERMISSION_DENIED:
                errorMessage = "Location is disabled";
                break;
            case error.POSITION_UNAVAILABLE:
                errorMessage = "Data unavailable";
                break;
            case error.TIMEOUT:
                errorMessage = "Timeout error";
                break;
            default:
                break;
        }

        document.getElementById("status").innerHTML = errorMessage;
    }

    app.oncheckpoint = function (args) {
    };

    app.start();
})();
