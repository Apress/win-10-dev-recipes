﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                // TODO: This application has been newly launched. Initialize
                // your application here.
            } else {
                // TODO: This application has been reactivated from suspension.
                // Restore application state here.
            }
            args.setPromise(WinJS.UI.processAll().
                done(function () {
                    document.querySelector("#btnstart").addEventListener("click",
                        starttracking);
                    document.querySelector("#btnstop").addEventListener("click",
                        stoptracking);

                }));

        }
    };
    var geolocation = null;
    var positionInstance;
    // on click of the start tracking
    function starttracking() {
        if (geolocation == null) {
            geolocation = window.navigator.geolocation;
        }
        if (geolocation != null) {
            positionInstance = geolocation.watchPosition(onsuccess, onerror);
        }
    }
    // on click of the stop tracking button
    function stoptracking() {
        geolocation.clearWatch(positionInstance);
    }
    // on success of getting the location
    function onsuccess(pos) {
        document.getElementById('latitude').innerHTML = pos.coords.latitude;
        document.getElementById('longitude').innerHTML = pos.coords.longitude;
    }

    // On error when trying to get the location
    function Onerror(error) {
        var errorMessage = "";
        switch (error.code) {
            case error.PERMISSION_DENIED:
                errorMessage = "Location is disabled";
                break;
            case error.POSITION_UNAVAILABLE:
                errorMessage = "Data unavailable";
                break;
            case error.TIMEOUT:
                errorMessage = "Timeout error";
                break;
            default:
                break;
        }

        document.getElementById("status").innerHTML = errorMessage;
    }

    app.oncheckpoint = function (args) {

    };

    app.start();
})();
