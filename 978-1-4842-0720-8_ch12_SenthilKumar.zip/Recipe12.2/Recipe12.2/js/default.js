﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=392286
(function () {
    "use strict";
    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                // TODO: This application has been newly launched. Initialize
                // your application here.
            } else {
                // TODO: This application has been reactivated from suspension.
                // Restore application state here.
            }
            args.setPromise(WinJS.UI.processAll().
                 done(function () {

                     // Add an event handler to the button.
                     document.querySelector("#start").addEventListener("click",
                         Starttracking);

                     // Add an event handler to the button.
                     document.querySelector("#stop").addEventListener("click",
                         Stoptracking);

                 }));
        }
    };
    var geolocation = null;
    // Start tracking
    function Starttracking() {
        if (geolocation == null) {
            geolocation = new Windows.Devices.Geolocation.Geolocator();
            geolocation.reportInterval = 100;
        }
        if (geolocation != null) {
            geolocation.addEventListener("positionchanged", onPositionChanged);
            geolocation.addEventListener("statuschanged", onStatusChanged);
        }
    }
    // On change of location position , update the UI
    function onPositionChanged(args) {
        document.getElementById('latitude').innerHTML = args.position.coordinate.point.position.latitude;
        document.getElementById('longitude').innerHTML = args.position.coordinate.point.position.longitude;
        document.getElementById('accuracy').innerHTML = args.position.coordinate.accuracy;
    }

    // Stop the tracking
    function Stoptracking() {
        if (geolocation != null) {
            geolocation.removeEventListener("positionchanged", onPositionChanged);
        }
    }
    // event handler for the Status Changed method.
    function onStatusChanged(args) {
        var Status = args.status;
        document.getElementById('Status').innerHTML =
            getStatus(Status);
    }
    // Gets the status
    function getStatus(Status) {
        switch (Status) {
            case Windows.Devices.Geolocation.PositionStatus.ready:
                return "Ready";
                break;
            case Windows.Devices.Geolocation.PositionStatus.initializing:
                return "Initializing";
                break;
            case Windows.Devices.Geolocation.PositionStatus.disabled:
                return "Location is disabled . Check the Location settings in your device or Appxmanifest file";
                break;
            case Windows.Devices.Geolocation.PositionStatus.notInitialized:
                return "Not Initialized";
            default:
                return "Status us unknown";
        }
    }

    app.oncheckpoint = function (args) {

    };

    app.start();
})();
