﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=392286
(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                // TODO: This application has been newly launched. Initialize
                // your application here.
            } else {
                // TODO: This application has been reactivated from suspension.
                // Restore application state here.
            }
            args.setPromise(WinJS.UI.processAll().
                done(function () {
                    Microsoft.Maps.loadModule('Microsoft.Maps.Map', { callback: GetMap });

                }));
        }
    };
    var map;
    function GetMap() {
        //   Microsoft.Maps.loadModule('Microsoft.Maps.Map', { callback: GetMap });
        var loc = new Microsoft.Maps.Location(13.0220, 77.4908);
        // Initialize the map 
        map = new Microsoft.Maps.Map(document.getElementById("myMap"), {
            credentials: "qI5baiUZ4SaWH5xjpiYO~cuSQGNlENpwINAQa36-Uqw~AjDqPD7GrCqQCjyrsE2-JAtjeXJkbEg7V_2WrylmFofxXkyt7u6rHKOf5Hd7Z8km",
            zoom: 10
        });
        var pin = new Microsoft.Maps.Pushpin(loc);
        map.entities.push(pin);

        // Center the map on the location
        map.setView({ center: loc, zoom: 10 });

       
        var routeRequest = 'http://dev.virtualearth.net/REST/v1/Routes?wp.0=' + start + '&wp.1=' + end + '&routePathOutput=Points&output=json&key=' + credentials;
        WinJS.xhr({ url: routeRequest }).then(routeCallback)
    }

    // api to use Rest direction service
    function getDirections() {
        map.getCredentials(function (credentials) {
            var start = 'HSR Layout , Bangalore'; var end = 'Microsoft India , Signature Building , Domlur , Bangalore';
            var routeRequest = 'http://dev.virtualearth.net/REST/v1/Routes?wp.0=' + start + '&wp.1=' + end +
                  '&routePathOutput=Points&output=json&key=' + credentials;
            WinJS.xhr({ url: routeRequest }).then(routeCallback);
        });
    }

    app.oncheckpoint = function (args) {

    };

    app.start();
})();
