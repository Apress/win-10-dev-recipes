﻿/// <reference path="../WinJS/js/base.js" />
var myData = new WinJS.Binding.List([
        { title: "Banana", text: "frozen yogurt", picture: "/images/60Banana.png" },
        { title: "Lemon", text: "Sorbet", picture: "/images/60Lemon.png" },
        { title: "Mint", text: "Gelato", picture: "/images/60Mint.png" },
        { title: "Orange", text: "Sorbet", picture: "/images/60Orange.png" },
        { title: "Berry", text: "Sorbet", picture: "/images/60Strawberry.png" },
        { title: "Vanilla", text: "Ice Cream", picture: "/images/60Vanilla.png" },
        { title: "Banana", text: "frozen yogurt", picture: "/images/60Banana.png" },
        { title: "Lemon", text: "Sorbet", picture: "/images/60Lemon.png" },
        { title: "Mint", text: "Gelato", picture: "/images/60Mint.png" },
        { title: "Orange", text: "Sorbet", picture: "/images/60Orange.png" },
        { title: "Berry", text: "Sorbet", picture: "/images/60Strawberry.png" },
        { title: "Vanilla", text: "Ice Cream", picture: "/images/60Vanilla.png" },
        { title: "Banana", text: "frozen yogurt", picture: "/images/60Banana.png" },
        { title: "Lemon", text: "Sorbet", picture: "/images/60Lemon.png" },
        { title: "Mint", text: "Gelato", picture: "/images/60Mint.png" },
        { title: "Orange", text: "Sorbet", picture: "/images/60Orange.png" },
        { title: "Berry", text: "Sorbet", picture: "/images/60Strawberry.png" },
        { title: "Vanilla", text: "Ice Cream", picture: "/images/60Vanilla.png" },
        { title: "Banana", text: "frozen yogurt", picture: "/images/60Banana.png" },
        { title: "Lemon", text: "Sorbet", picture: "/images/60Lemon.png" },
        { title: "Mint", text: "Gelato", picture: "/images/60Mint.png" },
        { title: "Orange", text: "Sorbet", picture: "/images/60Orange.png" },
        { title: "Strawberry", text: "Sorbet", picture: "/images/60Strawberry.png" },
        { title: "Vanilla", text: "Ice Cream", picture: "/images/60Vanilla.png" },
        { title: "Banana", text: "frozen yogurt", picture: "/images/60Banana.png" },
        { title: "Lemon", text: "Sorbet", picture: "/images/60Lemon.png" },
        { title: "Mint", text: "Gelato", picture: "/images/60Mint.png" },
        { title: "Orange", text: "Sorbet", picture: "/images/60Orange.png" },
        { title: "Berry", text: "Sorbet", picture: "/images/60Strawberry.png" },
        { title: "Vanilla", text: "Ice Cream", picture: "/images/60Vanilla.png" },
        { title: "Banana", text: "frozen yogurt", picture: "/images/60Banana.png" },
        { title: "Lemon", text: "Sorbet", picture: "/images/60Lemon.png" },
        { title: "Mint", text: "Gelato", picture: "/images/60Mint.png" },
        { title: "Orange", text: "Sorbet", picture: "/images/60Orange.png" },
        { title: "Berry", text: "Sorbet", picture: "/images/60Strawberry.png" },
        { title: "Vanilla", text: "Ice Cream", picture: "/images/60Vanilla.png" }
]);

WinJS.Namespace.define("ListViewExample", {
    data : myData
})