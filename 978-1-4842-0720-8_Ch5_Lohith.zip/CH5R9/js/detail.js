﻿/// <reference path="../WinJS/js/base.js" />
(function () {

    'use strict';

    WinJS.UI.Pages.define("/detail.html", {
        processed: function (element, options) {
            var that = this;
            WinJS.Binding.processAll(element, WinJS.Application.sessionState.selectedItem);
        }
    })

})();