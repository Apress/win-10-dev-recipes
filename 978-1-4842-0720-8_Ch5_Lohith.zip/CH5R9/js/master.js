﻿/// <reference path="../WinJS/js/base.js" />
(function () {
    'use strict';
    WinJS.UI.Pages.define("/master.html", {
        ready: function (element, options) {
            var that = this;
            element.addEventListener("iteminvoked", function (evt) { 
                evt.detail.itemPromise.then(function (item) { 
                    WinJS.Application.sessionState.selectedItem = item.data;
                    WinJS.Navigation.navigate("/detail.html"); 
                }); 
            }); 
        }
    })
})();