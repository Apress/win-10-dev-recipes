﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
	"use strict";

	var Person = WinJS.Binding.define({
	    name: "",
	    color: "",
	    birthday: "",
	    petname: "",
	    dessert: ""
	})

	var people = [
        new Person({ name: "John Doe", color: "red", birthday: "2/2/2002", petname: "Spot", dessert: "chocolate cake" }),
        new Person({ name: "Jane Doe", color: "green", birthday: "3/3/2003", petname: "Xena", dessert: "cherry pie" }),
        new Person({ name: "Jake Doe", color: "blue", birthday: "2/2/2002", petname: "Pablo", dessert: "ice cream" }),
	];

	var app = WinJS.Application;
	var activation = Windows.ApplicationModel.Activation;

	app.onactivated = function (args) {
		if (args.detail.kind === activation.ActivationKind.launch) {
			if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
				// TODO: This application has been newly launched. Initialize your application here.
			} else {
				// TODO: This application was suspended and then terminated.
				// To create a smooth user experience, restore application state here so that it looks like the app never stopped running.
			}

			var selector = document.querySelector("#templateControlObjectSelector");
			selector.addEventListener("change", handleChange, false);
			selector.options[0].selected = true;
			args.setPromise(WinJS.UI.processAll());

		}
	};

	app.oncheckpoint = function (args) {
		// TODO: This application is about to be suspended. Save any state that needs to persist across suspensions here.
		// You might use the WinJS.Application.sessionState object, which is automatically saved and restored across suspension.
		// If you need to complete an asynchronous operation before your application is suspended, call args.setPromise().
	};

	function handleChange(evt) {
	    var templateElement = document.querySelector("#templateDiv");
	    var renderElement = document.querySelector("#renderDiv");
	    renderElement.innerHTML = "";

	    var selected = evt.target.selectedIndex;
	    var templateControl = templateElement.winControl;
	    templateElement.winControl.render(people[selected], renderElement);
	}


	app.start();
})();
